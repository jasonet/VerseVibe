import"./_virtual_wxt-html-plugins-DPbbfBKe.js";import{b as R}from"./browser-polyfill-DX5UB71L.js";const u=document.getElementById("vv-viewer-root");function A(){const r=document.createElement("style");r.textContent=`
:root { color-scheme: dark; }
* { box-sizing: border-box; }
html, body { margin: 0; height: 100%; background: #0b0b0c; color: #e8e8ea;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "PingFang SC", "Microsoft YaHei", sans-serif; }
#vv-viewer-root { height: 100vh; display: flex; flex-direction: column; }

.vv-topbar { display: flex; align-items: center; gap: 12px; padding: 10px 16px;
  background: rgba(20,20,22,.92); border-bottom: 1px solid #232327; flex: 0 0 auto; }
.vv-title { font-size: 14px; font-weight: 600; white-space: nowrap; overflow: hidden;
  text-overflow: ellipsis; max-width: 46vw; opacity: .92; }
.vv-counter { font-size: 13px; opacity: .7; min-width: 56px; }
.vv-spacer { flex: 1 1 auto; }
.vv-btn { appearance: none; border: 1px solid #34343a; background: #1b1b1f; color: #e8e8ea;
  border-radius: 8px; padding: 6px 12px; font-size: 13px; cursor: pointer; line-height: 1; }
.vv-btn:hover { background: #26262c; }
.vv-link { color: #6db3ff; text-decoration: none; font-size: 13px; }
.vv-link:hover { text-decoration: underline; }

.vv-stage { position: relative; flex: 1 1 auto; overflow: hidden; display: flex;
  align-items: center; justify-content: center; background:
  repeating-conic-gradient(#101012 0% 25%, #0b0b0c 0% 50%) 50% / 28px 28px; }
.vv-img { max-width: 100%; max-height: 100%; user-select: none; -webkit-user-drag: none;
  transform-origin: center center; transition: transform .04s linear;
  will-change: transform; cursor: grab; }
.vv-img.dragging { cursor: grabbing; transition: none; }

.vv-nav { position: absolute; top: 50%; transform: translateY(-50%); z-index: 5;
  width: 46px; height: 72px; border: none; border-radius: 10px; cursor: pointer;
  background: rgba(0,0,0,.42); color: #fff; font-size: 26px; line-height: 1; }
.vv-nav:hover { background: rgba(0,0,0,.66); }
.vv-prev { left: 14px; } .vv-next { right: 14px; }
.vv-zoomhint { position: absolute; left: 50%; bottom: 14px; transform: translateX(-50%);
  z-index: 5; font-size: 12px; opacity: .55; background: rgba(0,0,0,.4);
  padding: 4px 10px; border-radius: 999px; white-space: nowrap; }

.vv-thumbs { flex: 0 0 auto; display: flex; gap: 8px; padding: 8px 12px; overflow-x: auto;
  background: rgba(18,18,20,.92); border-top: 1px solid #232327; }
.vv-thumb { flex: 0 0 auto; width: 72px; height: 54px; object-fit: cover; border-radius: 6px;
  cursor: pointer; opacity: .55; border: 2px solid transparent; background: #000; }
.vv-thumb:hover { opacity: .85; }
.vv-thumb.active { opacity: 1; border-color: #6db3ff; }

.vv-textpanel { position: absolute; right: 0; top: 0; bottom: 0; width: min(420px, 84vw);
  background: rgba(16,16,18,.97); border-left: 1px solid #2a2a30; padding: 18px 20px;
  overflow-y: auto; transform: translateX(100%); transition: transform .22s ease; z-index: 8; }
.vv-textpanel.open { transform: translateX(0); }
.vv-textpanel h3 { margin: 0 0 10px; font-size: 14px; opacity: .7; font-weight: 600; }
.vv-textpanel .vv-body { white-space: pre-wrap; line-height: 1.6; font-size: 15px; }

.vv-empty { margin: auto; opacity: .6; font-size: 15px; text-align: center; line-height: 1.8; }
`,document.head.appendChild(r)}function H(r){const t=(r.images||[]).filter(Boolean);let n=0,a=1,c=0,l=0;u.innerHTML="";const h=document.createElement("div");h.className="vv-topbar";const b=document.createElement("div");b.className="vv-title",b.textContent=r.title||"LinkedIn 帖子";const f=document.createElement("div");f.className="vv-counter";const N=document.createElement("div");N.className="vv-spacer";const p=document.createElement("button");p.className="vv-btn",p.textContent="正文";const d=document.createElement("a");d.className="vv-link",d.textContent="看原帖 ↗",d.target="_blank",d.rel="noopener noreferrer",d.href=r.url||"#",r.url||(d.style.display="none"),h.append(b,N,f,p,d),u.appendChild(h);const v=document.createElement("div");if(v.className="vv-stage",u.appendChild(v),!t.length){const e=document.createElement("div");e.className="vv-empty",e.textContent=`没有抓到可显示的图片。
可点右上「看原帖」回到 LinkedIn 查看。`,v.appendChild(e),f.textContent="0 / 0",p.style.display=r.text?"":"none",$();return}const o=document.createElement("img");o.className="vv-img",o.draggable=!1,v.appendChild(o);const m=document.createElement("button");m.className="vv-nav vv-prev",m.textContent="‹";const g=document.createElement("button");g.className="vv-nav vv-next",g.textContent="›",v.append(m,g);const y=document.createElement("div");y.className="vv-zoomhint",y.textContent="滚轮缩放 · 拖拽平移 · 双击复位 · ← → 切换",v.appendChild(y);const w=document.createElement("div");w.className="vv-thumbs";const k=[];t.forEach((e,s)=>{const i=document.createElement("img");i.className="vv-thumb",i.src=e,i.addEventListener("click",()=>x(s)),w.appendChild(i),k.push(i)}),t.length>1&&u.appendChild(w);function E(){o.style.transform=`translate(${c}px, ${l}px) scale(${a})`}function C(){a=1,c=0,l=0,E()}function z(){o.src=t[n],f.textContent=`${n+1} / ${t.length}`,m.style.visibility=t.length>1?"visible":"hidden",g.style.visibility=t.length>1?"visible":"hidden",k.forEach((s,i)=>s.classList.toggle("active",i===n));const e=k[n];e&&e.scrollIntoView({block:"nearest",inline:"center"}),C()}function x(e){n=(e+t.length)%t.length,z()}m.addEventListener("click",()=>x(n-1)),g.addEventListener("click",()=>x(n+1)),v.addEventListener("wheel",e=>{e.preventDefault();const s=o.getBoundingClientRect(),i=e.clientX-(s.left+s.width/2),B=e.clientY-(s.top+s.height/2),j=e.deltaY<0?1.12:1/1.12,M=Math.min(8,Math.max(1,a*j)),P=M/a;c=(c-i)*P+i,l=(l-B)*P+B,a=M,a===1&&(c=0,l=0),E()},{passive:!1});let L=!1,I=0,S=0,V=0,X=0;o.addEventListener("pointerdown",e=>{a<=1||(L=!0,o.classList.add("dragging"),I=e.clientX,S=e.clientY,V=c,X=l,o.setPointerCapture(e.pointerId))}),o.addEventListener("pointermove",e=>{L&&(c=V+(e.clientX-I),l=X+(e.clientY-S),E())});const Y=()=>{L=!1,o.classList.remove("dragging")};o.addEventListener("pointerup",Y),o.addEventListener("pointercancel",Y),o.addEventListener("dblclick",C),window.addEventListener("keydown",e=>{e.key==="ArrowLeft"?x(n-1):e.key==="ArrowRight"?x(n+1):e.key==="0"?C():e.key==="Escape"&&window.close()}),$(),z();function $(){const e=document.createElement("div");e.className="vv-textpanel";const s=document.createElement("h3");s.textContent="帖子正文";const i=document.createElement("div");i.className="vv-body",i.textContent=r.text||"（未抓取到正文）",e.append(s,i),u.appendChild(e),p.addEventListener("click",()=>e.classList.toggle("open")),r.text||(p.style.opacity=".5")}}async function T(){A();const t=new URLSearchParams(location.search).get("k")||"";let n={images:[]};if(t)try{const a=await R.storage.local.get(t);a&&a[t]&&(n=a[t]),await R.storage.local.remove(t)}catch(a){console.warn("[VerseVibe viewer] 读取数据失败",a)}n.title&&(document.title=`VerseVibe · ${n.title}`),H(n)}T();
